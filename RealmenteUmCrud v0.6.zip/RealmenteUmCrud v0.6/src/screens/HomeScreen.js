import React, {useEffect, useState} from "react";
import {View, Text, FlatList, Button, TextInput} from "react-native";

import styles from "../styles/styles";
import {getPeople, deletePerson} from "../servers/PeopleCrud";

export default function HomeSrceen({ navigation }) {
    const [people, setPeople] = useState([]);
    const [filteredPeople, setFilteredPeople] = useState([]);
    const [search, setSearch] = useState("");

    async function loadPeople(){
        const data = await getPeople();
        setPeople(data);
        setFilteredPeople(data); // lista inicial
    }

    useEffect(()=>{
        loadPeople();
    },[]);

    //Função de filtragem
    function handleSearch(text) {
        setSearch(text);

        const filtered = people.filter((p) =>
            `${p.firstName} ${p.lastName}`
                .toLowerCase()
                .includes(text.toLowerCase())
        );

        setFilteredPeople(filtered);
    }

    return(
        <View style={styles.container}>

            <Text style={styles.title}>Pessoas</Text>

            <Button
                title="Adicionar Pessoa"
                onPress={() => navigation.navigate("AddEdit")}
            />

            {/*campo busca*/}
            <TextInput
                style={{
                    borderWidth: 1,
                    borderColor: "#ccc",
                    borderRadius: 8,
                    padding: 10,
                    marginVertical: 15
                }}
                placeholder="Buscar pessoa..."
                value={search}
                onChangeText={handleSearch}
            />

            <FlatList
                data={filteredPeople}
                keyExtractor={(item)=>item.id.toString()}
                renderItem={({item})=>(
                    <CardPersonal
                        item={item}
                        navigation={navigation}
                        refresh={loadPeople}
                    />
                )}
            />
        </View>
    );
}

/*-- CARD RAHHHHHHHHHHHHHHHHHAUSHCXIAUHCOAIUHCOAICUH--*/

function CardPersonal({item, navigation, refresh}){
    return(
        <View style={styles.card}>
            <View>

                <Text style={styles.name}>
                    {item.firstName} {item.lastName}
                </Text>

                <Text style={styles.email}>
                    {item.email}
                </Text>

                <Text style={styles.phone}>
                    {item.phone}
                </Text>

            </View>

            <View>
                <Button
                    title="Adicionar e Editar"
                    onPress={()=> navigation.navigate("AddEdit",{person:item})}
                />

                <Button
                    title="Deletar"
                    onPress={async ()=>{
                        await deletePerson(item.id);
                        refresh();
                    }}
                />
            </View>

        </View>
    );
}