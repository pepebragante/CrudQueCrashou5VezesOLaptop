import { API_URL } from "./ConfigApi";

// GET — lista todas as pessoas
export async function getPeople() {
    const response = await fetch(`${API_URL}/people`);
    return response.json();
}

// POST — cria uma nova pessoa
export async function createPerson(person) {
    const response = await fetch(`${API_URL}/people`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(person)
    });

    return response.json();
}

// PUT — atualiza uma pessoa existente
export async function updatePerson(id, person) {
    const response = await fetch(`${API_URL}/people/${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(person)
    });

    return response.json();
}

// DELETE — remove uma pessoa
export async function deletePerson(id) {
    await fetch(`${API_URL}/people/${id}`, {
        method: "DELETE"
    });
}